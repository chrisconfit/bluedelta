'use strict';
// Auto-generated file, do not modify directly

var config = {
  "REGION": "us-east-1",
  "PROFILE_IMAGES_S3_BUCKET": "blue-delta-api-development-stack-userdatabucket-1roa31kj25t6q",
  "API_ENDPOINT": "https://ritgmsrczb.execute-api.us-east-1.amazonaws.com/development",
  "USER_POOL_ID": "us-east-1_hbjWOqI1M",
  "CLIENT_ID": "1slpl86p8rf8ea6mhq00tl1b2r",
  "IDENTITY_POOL_ID": "us-east-1:60cb9dd2-a77d-4f65-94eb-bf32a0a7cacf"
};

module.exports = { config };